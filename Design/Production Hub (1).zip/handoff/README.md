# Production Hub — UI Refinement Handoff

Three approved changes, ready to implement. Each has a live mockup in `mockups/`.
**Design language unchanged** — Nordic minimalist: warm off-white (`#F1EEE9`), charcoal ink
(`#1A1714`), hairline borders, chunky 1.5px outlines with hard offset shadows, Bricolage Grotesque display + Assistant/Heebo for body & Hebrew.

> These are visual specs, not production code. Build into the real app against the existing
> component tree (`App.jsx`, `ShowForm.jsx`, `CrewManager.jsx`, `GlobalTaskPanel.jsx`, `TeamPanel.jsx`).

---

## Design tokens (single source of truth)

```css
:root{
  /* surfaces */
  --bg:#F1EEE9; --surface:#FBF8F2; --surface-2:#FFFDF8; --surface-sunk:#EBE7E0;
  /* lines */
  --border:#DDD7CE; --border-light:#E7E2D9; --border-strong:#C8C1B5;
  /* ink */
  --text:#1A1714; --text-2:#6B6259; --text-3:#A39A91;
  /* accent + artist palette */
  --accent:#3852B4; --accent-hover:#2D4399; --accent-soft:#E8ECF7;
  --a1:#3852B4; --a2:#F08D39; --a3:#C79A3F; --a4:#4E7265;   /* deep blue · terracotta · mustard · pine */
  /* status */
  --orange:#F08D39; --danger:#C0392B; --danger-bg:#F6E0DC; --ok:#4E7265; --ok-bg:#E6EDEA;
  /* shape */
  --radius-sm:6px; --radius:10px; --radius-pill:999px;
}
```

---

## 1 · Unified Component Kit  → `mockups/Component Kit.html`  ✅ APPROVED

Replaces the **7 button classes** (`btn-primary/secondary/ghost/action/action--danger/sm/sync`)
and **5 tab/filter variants** (`filter-btn`, `crew-tab`, `gtask-filter-btn`, `team-tab-btn`,
`bk-inline-tab-btn`) with four primitives.

### `<Button>` — role × size × modifier
- **Roles:** `primary` (filled accent, 3px offset shadow), `secondary` (outlined, sunk shadow),
  `ghost` (text only, sunk hover).
- **Sizes:** `sm` 32px · `md` 40px · `lg` 48px. Heights are fixed; padding 13/18/24px.
- **Modifier:** `danger` recolors any role to `--danger`.
- Border `1.5px var(--text)`, radius `6px`, weight `700`. Press = `translate(1px,1px)` + shadow shrink.
- **Icon button:** square `var(--btn-icon-size)` — **min 44px** (see Quick Win #1).

```
<Button role="primary" size="md">Add Show</Button>
<Button role="secondary" size="md">Sync</Button>
<Button role="ghost" size="sm" danger>Remove</Button>
```

### `<SegmentedControl>` — page sub-tabs & view switches
- One outlined pill bar, `1.5px var(--text)` dividers. Active segment = filled accent.
- Optional `count` badge per segment (pill, tabular-nums).
- Drives: Shows status filter · Crew Members/Types · Tasks filter · Team tabs · Calendar Month/Week.

### `<FilterChip>` — toggleable multi-select
- States: **on** (solid border, full opacity) · **off** (dashed border, 50% opacity).
- Optional 10px color `swatch` (artist palette) + optional `count` badge.
- "All" chip toggles the whole group; derives its own on/off from children.

### `<MetricBox>` — one stat card everywhere
- Outlined `1.5px var(--text)`, `4px 4px 0 var(--surface-sunk)` shadow. **No filled variant**
  (removes the odd indigo-filled first card in Team stats).
- Number `2.6rem/800` tabular-nums · label `.68rem` uppercase + 7px accent dot.

---

## 2 · ShowForm → Option B (Sticky Section Rail)  → `mockups/ShowForm Option B.html`  ✅ CHOSEN

Replaces the long single-scroll form. **Same fields, same data model** — only the layout changes.

### Structure
- **Two-pane modal**, `min(880px)` wide, `max-height:88vh`. Header shows eyebrow `EDIT SHOW` +
  the live show name as the `1.5rem/800` title.
- **Left rail** `194px`, `border-right:1.5px var(--border)`:
  - One `rail-link` per section: **Basics · Logistics · Crew · Brief Content · Custom**.
  - 8px status dot per link (grey default, **orange if section has a flagged/missing field**,
    accent when active). Optional count badge (`Crew 5`, `Custom 2`).
  - Click → smooth-scroll form to that section. **Do not use `scrollIntoView`** — use
    `form.scrollTo({top: section.offsetTop - 26, behavior:'smooth'})`.
  - Scroll spy: on form scroll, the section whose `offsetTop <= scrollTop + 80` is `active`.
  - Footer of rail: `Last saved … by …` meta.
- **Right form** scrolls; sections use `scroll-margin-top`. Section header = `1.15rem/800` with
  `border-bottom:2px solid var(--accent)` and an optional grey sub-label.
- Fields: `.62rem` uppercase label (accent `*` for required) over a `1.5px` input,
  **min-height 44px**, focus ring `0 0 0 3px var(--accent-soft)`. Two-column grid; full-width fields span both.

### Field → section map (preserve existing keys)
| Section | Fields |
|---|---|
| Basics | Show Name* · Date* · Event Type · Venue · Address |
| Logistics | Parking · Transportation · Load-in Notes |
| Crew | crew chips (tap to toggle assignment) + "Add crew" |
| Brief Content | **Schedule (structured)** · Contacts · Additional Details |
| Custom | event-type custom fields |

### ⭐ Key upgrade — structured Schedule
Replace the free-text schedule textarea with **time + activity rows**:
- Each row: time input (`96px`, accent, tabular-nums) + activity input (flex, RTL) + 44px delete button.
- "＋ Add row" appends. Store as an **array of `{time, activity}`** instead of a string.
- This is what feeds the coordination sheet (דף תיאום) `{{SCHEDULE}}` block — structured data in,
  clean rendered rows out. Migrate existing string schedules by splitting on newlines.

### RTL
All Hebrew content fields are `dir="rtl"` / right-aligned; chrome (labels, rail) stays LTR.

---

## 3 · Quick Wins  → `mockups/Quick Wins.html`

| # | Fix | Type | Where |
|---|---|---|---|
| 1 | **44px icon-button hit-targets** — pad tap area, keep glyph small | CSS | ShowCard, CrewManager, TeamPanel (✎ ✕ ···) |
| 2 | **One "Saved ✓" pattern** — footer pill, fade in 220ms / hold 2.2s / fade out | CSS | every save action |
| 3a | Delete unused `EventTypesTab` (~90 lines, never rendered) | Code | `CrewManager.jsx:561` |
| 3b | Fix `roleColor = () => '#F08D39'` — ignores its `role` arg; inline the token or make it map roles→colors | Code | `CrewManager.jsx:7` |

---

## Suggested order
1. **Component Kit** first — everything else consumes it.
2. **Quick Wins** — fast, ship same PR as the kit (icon buttons live in the kit anyway).
3. **ShowForm Option B** — the bigger lift; the structured Schedule needs a small data migration.

## Out of scope (proposed earlier, not approved — revisit later)
Compact hero on operational pages · Team permissions drawer · Tasks meta collapse ·
Automations builder behind a toggle · ShowCard PDF-field disclosure.

---
*Mockups are standalone HTML — open directly in a browser. Hebrew sample data included to verify RTL.*

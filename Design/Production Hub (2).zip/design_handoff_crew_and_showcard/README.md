# Handoff: Crew Cards Redesign + ShowCard Improvements

## Overview
This package covers two related design updates for **Production Hub** (a Hebrew-first / RTL show-production management app):

1. **Crew Cards redesign** — the member cards on the **Crew & Types** page (grouped by category: Backline, Production, Musician). Chosen direction: **Option B (Avatar + Icon Contacts)** with **per-group color coding**.
2. **ShowCard + Edit Form improvements** — enrichments to the show cards and the addition of a new **Technical** section in the show edit form.

---

## About the Design Files
The files in `prototypes/` are **design references created in HTML** — interactive prototypes showing the intended look and behavior. They are **not production code to copy directly**.

The task is to **recreate these designs inside the existing Production Hub codebase** (React, using its established component patterns — `ShowCard`, `ShowForm`, `TaskManager`, `TechnicalManager`, the existing CSS in the app stylesheet). Reuse existing components, helpers, and tokens wherever they already exist. The HTML/inline-styles in the prototypes are illustrative; map them onto the app's real CSS classes and design tokens.

The codebase already uses CSS custom properties and a warm-beige visual system — use those, do not introduce a new styling approach.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and interactions are intended to be final. Recreate pixel-faithfully using the app's existing CSS variables and component conventions.

---

## Design Tokens

These mirror the app's existing palette (warm beige / black-border system). Use the app's real CSS variables if they already exist; the hex values below are the source of truth.

| Token | Hex | Usage |
|---|---|---|
| `--bg` | `#F1EEE9` | Page background |
| `--surface` | `#FBF8F2` | Card background |
| `--surface-2` | `#FFFDF8` | Raised surface |
| `--sunk` | `#EBE7E0` | Sunk panels, table header rows, hover |
| `--border` | `#DDD7CE` | Default hairline border |
| `--border-strong` | `#C8C1B5` | Stronger dividers |
| `--ink` | `#1A1714` | Primary text + strong card borders |
| `--ink-2` | `#6B6259` | Secondary text |
| `--ink-3` | `#A39A91` | Tertiary / muted labels |
| `--orange` | `#F08D39` | Brand accent |
| `--orange-bg` | `#FCE3CC` | Orange tint background |
| `--orange-dark` | `#C26C1F` | Clay accent / Production group |
| `--blue` | `#3852B4` | Accent / Backline group |
| `--blue-bg` | `#E8ECF7` | Blue tint |
| `--green` | `#16A34A` | Success / positive |

**Group colors** (per-group, shared by all members of a group):
| Group | Color |
|---|---|
| Backline | `#3852B4` (blue) |
| Production | `#C26C1F` (clay) |
| Musician | `#4E7265` (green) |

> Other groups beyond these three should be assigned from a stable palette so each group is visually distinct: `['#3852B4','#C26C1F','#4E7265','#7C3A5E','#1F2D6E','#B07729']`. Pick by a deterministic function of the group id/index so the color is stable across reloads.

**Event-type tag (chip) style:**
- background `#F5EDD8`, text `#7A5A1E`, border `1px solid #E5D0A0`
- font-size `0.68rem`, font-weight `500`, padding `2px 9px`, no border-radius (square corners)

### Typography
- **Display / UI headings:** `'Bricolage Grotesque', sans-serif` — weights 700/800, tight tracking (`letter-spacing: -0.04em` on large sizes)
- **Body / names / Hebrew content:** `'Assistant', sans-serif`
- **Section/eyebrow labels:** uppercase, `font-size: 0.6–0.7rem`, `font-weight: 700`, `letter-spacing: 0.1em`, color `--ink-3`
- **Numbers (phone, times):** add `font-variant-numeric: tabular-nums`

### Misc
- Corners are **square** throughout (no border-radius) except circular avatars.
- Borders: hairline `1px solid var(--border)`; emphasized cards `1px solid var(--ink)`.
- All Hebrew text containers use `dir="rtl"` (or `dir="auto"`); phone numbers/emails are LTR.

---

## Part 1 — Crew Cards (Option B: Avatar + Icon Contacts)

**Screen:** Crew & Types → Members tab. Members are grouped into collapsible sections (Backline, Production, Musician…). Each section renders a responsive card grid.

### Layout
- Section header row: collapse toggle (square, `1.5px solid var(--orange)`, shows `−`/`+`), group label (uppercase eyebrow), member count (`--ink-3`), then a hairline rule filling remaining width (`flex:1; height:1px; background:var(--border)`).
- Card grid: `display:grid; grid-template-columns:repeat(auto-fill, minmax(260px, 1fr)); gap:14px`.

### Card anatomy (per member)
- Container: `background:var(--surface); border:1px solid var(--ink); padding:18px 18px 14px;` vertical flex, `gap:12px`.
- **Top row** (`display:flex; align-items:center; gap:12px`):
  - **Avatar:** 42px circle, `border-radius:50%`, background = **the group's color** (all members in a group share it), white initials, `font-weight:800`, `font-size:~14px` (size×0.33), `letter-spacing:-0.02em`. Initials = first letter of up to the first two name words, uppercased.
  - **Name + label block** (`flex:1; min-width:0` — **required** to prevent the label overlapping the RTL name):
    - Name: `dir="rtl"`, `'Assistant'`, `1rem`, `font-weight:700`, `line-height:1.2`.
    - Group label below: uppercase eyebrow, `0.65rem`, `font-weight:700`, `letter-spacing:0.1em`, **color = group color**, `margin-top:2px`.
- **Contact rows** (`display:flex; flex-direction:column; gap:5px`):
  - Phone row: small phone icon (11px, `--ink-3`) + number (`0.82rem`, `--ink-2`, tabular-nums).
  - Email row: small mail icon (11px, `--ink-3`) + email (`0.82rem`, `--ink-2`).
  - Omit a row entirely if the field is empty.
- **Tags block** (only if member has event types): top divider `1px solid var(--border)`, `padding-top:10px`, then wrapped chips (`display:flex; flex-wrap:wrap; gap:5px`) using the chip style above.

**Icons:** simple 11px line icons (Feather-style phone & mail), `stroke-width:2.2`, `stroke:currentColor`. Use the codebase's existing icon set if available (e.g. lucide/feather) rather than inlining SVG.

### Behavior
- Group sections collapse/expand on header-toggle click (the app already supports this).
- Cards are static display; clicking a card (or an edit affordance) opens the member editor — wire to the existing member-edit flow.
- Avatar color is derived from the member's **group**, not the individual — so a member moving groups changes their avatar color.

---

## Part 2 — ShowCard & Edit Form Improvements

See `prototypes/ShowCard Improvements Demo.html` (two tabs: **Show Cards** current-vs-proposed, and **Edit Form**).

### 2a. Collapsed-card meta enrichment
In the collapsed `ShowCard` header, after date + venue add, separated by `·` dots (`color:var(--border)`):
- **Time range** — derived from the schedule text: first and last `HH:MM` found, shown as `16:00 – 23:30`, prefixed with a clock glyph, `color:var(--accent)`, `font-weight:600`, tabular-nums.
- **Crew summary** — up to 3 overlapping mini avatars (16px, `-4px` overlap via negative margin, `1.5px solid var(--surface)` ring) + `"{n} crew"` label.

Helper: extract times with `/\d{1,2}:\d{2}/g` over the schedule string; range only shown when ≥1 match.

### 2b. Completion progress bar
Below the meta line, a thin progress indicator. Completion = fraction of these that are present: `schedule`, `crewIds.length>0`, `venue`, `contacts`, `address`.
- Track: `height:2px; background:#DDD7CE`. Fill width = `pct%`, transition `width .5s ease`.
- Color: `100% → #4E7265`, `≥60% → #3852B4`, else `#F08D39`. Numeric `NN%` label to the side, tabular-nums.

### 2c. Move Technical + Logistics INTO the accordion
**Current problem:** Technical and Logistics buttons live in the always-visible footer, so they can be opened on a collapsed card with no show context.
**Change:** Remove them from the footer. Render them **inside the expanded body** under an "Expand section" eyebrow, as a two-button segmented toggle (`Technical` | `Logistics`). Selecting one reveals its panel (the existing `TechnicalManager` / logistics panel content) directly below, within the expanded region.
- Footer keeps only: **Brief**, **PDF**, and the **Invoice** / **Receipt** checkboxes.
- Segmented buttons: `1px solid var(--ink)`, active = filled `var(--ink)` / `var(--surface)` text; uppercase `0.72rem`, `font-weight:700`, `letter-spacing:0.05em`.

### 2d. Sticky header on expanded card
When a card is expanded, its header (`ETBadge` + actions + title + meta + progress) becomes `position:sticky; top:0; z-index:10; background:var(--surface)` with a bottom border and a soft shadow (`0 2px 8px -4px rgba(26,23,20,0.12)`), so the show name stays visible while scrolling a long expanded card. Collapsed cards use normal positioning.

### 2e. NEW "Technical" section in the Edit Form (ShowForm)
**Current problem:** `ShowForm` has 5 sections (`Basics`, `Logistics`, `Crew`, `Brief Content`, `Custom`) and **no Technical section** — technical data is only reachable from `TechnicalManager` on the card itself, so editing a show can't capture it.
**Change:** Add **Technical** as a 6th section in the sidebar rail (between `Brief Content` and `Custom`). Fields:
- **Technical Spec** — file attach (PDF/image).
- **Setlist** — multiline textarea (`dir="auto"`).
- **Equipment Checklist** — repeatable list of text inputs with add/remove rows.
- **Technical Coordination** — for `Sound` and `Lighting` each: a **Rental Needs** text input + a **Supplier** text input (grid `110px 1fr 1fr`).

Persist into the show's `technical` object: `{ setlist, equipment: string[], soundRental, soundSupplier, lightingRental, lightingSupplier }` (matching what `TechnicalManager` reads/writes, so the card panel and the form stay in sync).

Form field styling: label = uppercase eyebrow (`0.62rem`, `font-weight:700`, `letter-spacing:0.08em`, `--ink-3`); input = `padding:8px 12px; border:1px solid var(--border); background:var(--bg); font-family:'Assistant'; border-radius:4px`.

---

## Additional ideas (not built — for discussion)
Duplicate/Clone show · "Today" section at top of Shows list · Bulk PDF export · Hover preview tooltip on collapsed cards · Autosave draft to localStorage while editing · Keyboard shortcuts (e/n/t).

---

## Files in this bundle
- `prototypes/Crew Card Options.html` — all 6 explored crew-card directions; **Option B is the selected one** (default tab). Group colors applied.
- `prototypes/ShowCard Improvements Demo.html` — current-vs-proposed for ShowCard, and the new Technical section in the Edit Form.

## Relevant existing source files (in the app repo)
- `ShowCard` component — collapsed/expanded card, footer, Technical/Logistics panels.
- `ShowForm` component — section rail + form fields (add Technical section here).
- `TechnicalManager` — current technical data UI (reuse its fields/state shape for both the card panel and the new form section).
- `TaskManager` — logistics/tasks panel.
- App stylesheet — existing CSS variables and `.show-*` classes to reuse.

# Claude Code — Implementation Prompt

Paste this into Claude Code from the root of the Production Hub repo. The `design_handoff_crew_and_showcard/` folder (README.md + `prototypes/`) should be present in the repo or alongside it.

---

## Prompt

```
I'm implementing two design updates in this React app (Production Hub — a Hebrew/RTL
show-production manager). Full spec is in design_handoff_crew_and_showcard/README.md,
with interactive HTML prototypes in design_handoff_crew_and_showcard/prototypes/.

The HTML files are DESIGN REFERENCES, not code to copy. Recreate the designs using
this repo's existing components, CSS variables, and patterns. Reuse existing CSS
custom properties and the warm-beige system already in the stylesheet — do not add a
new styling approach or component library.

Please read the README first, then the two prototype files, then the relevant source
components (ShowCard, ShowForm, TechnicalManager, TaskManager, and the app stylesheet)
before writing code.

Implement in this order, pausing after each for me to review:

1. CREW CARDS (Crew & Types → Members) — adopt "Option B: Avatar + Icon Contacts".
   - Add a 42px circular avatar with white initials to each member card.
   - Avatar color is PER GROUP: every member of a group shares one color, each group
     differs (Backline #3852B4, Production #C26C1F, Musician #4E7265; assign other
     groups deterministically from the README palette so colors are stable).
   - Tint the small group label under the name with that same group color.
   - Phone/email become icon + value rows (use the repo's existing icon set); omit a
     row when the field is empty. Keep event-type chips with the existing chip style.
   - Watch the name+label block: it MUST have flex:1 + min-width:0 or the RTL name
     overlaps the label.

2. SHOWCARD enrichments (collapsed + expanded):
   - Collapsed header: add time-range (first–last HH:MM parsed from schedule) and an
     overlapping mini-avatar crew summary ("{n} crew"), plus a thin completion
     progress bar (see README for the completeness formula and colors).
   - Move the Technical + Logistics buttons OUT of the always-visible footer and INTO
     the expanded body as a segmented toggle that reveals the existing
     TechnicalManager / logistics panels. Footer keeps only Brief, PDF, Invoice,
     Receipt.
   - Make the expanded card's header sticky (position:sticky; top:0) so the show name
     stays visible while scrolling.

3. EDIT FORM new section — add a "Technical" section to ShowForm's sidebar (between
   "Brief Content" and "Custom") with: Technical Spec file attach, Setlist textarea,
   Equipment checklist (repeatable rows), and Sound/Lighting Rental+Supplier fields.
   Persist to the show's `technical` object using the SAME shape TechnicalManager
   reads/writes, so the card panel and the form stay in sync.

Match the design tokens, typography, square corners, and RTL handling described in the
README. Keep everything keyboard-accessible and respect prefers-reduced-motion for the
progress-bar and any transitions.
```

---

## Notes for the developer
- Verify the exact prop/state shape of `TechnicalManager` before building the new form section — the goal is that the card panel and the edit-form section read/write the **same** `technical` object.
- Group color must derive from the member's **group**, not the individual id, so moving a member between groups recolors their avatar.
- All three changes are independent; they can ship as separate PRs.

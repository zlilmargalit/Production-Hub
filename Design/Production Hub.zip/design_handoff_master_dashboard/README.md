# Handoff: Master Dashboard (Global Home)

## Overview
The **Master Dashboard** is the global home page for the Agency Producer — a
cross-artist view over ALL productions. Three regions: a color-coded **Master
Calendar**, an **Up Next** agenda sidebar, and a full-width **My Tasks** list.
The top-right **Workspace Selector** is also the app's home-navigation pattern.

## About the design file
`Master Dashboard.html` is a **design reference** — a standalone HTML/JS
prototype showing the intended look, layout, spacing, and interactions. **Do not
ship the HTML.** Recreate it in the existing Production Hub React app using its
`App.css` token system and component patterns. Open the file in a browser and
click an event (popover) and the top-right Workspace pill (dropdown) to see all
states.

## Fidelity
**High-fidelity.** Colors, type, spacing, borders, and the hard-offset shadow
language are final. Reproduce pixel-faithfully.

## ⚠️ Regressions to fix vs the current Railway build
1. Stat row must be **exactly 3** identical outlined boxes (remove "Need
   Attention"; do not fill the first box solid indigo).
2. Hero: "GLOBAL VIEW · AGENCY PRODUCER" is an **eyebrow ABOVE** the title (small,
   uppercase, indigo, pulsing dot), not beside it. Title is **"Today."** with ONE
   period (current shows "Today..").
3. Calendar events must be **color-coded per artist** (left bar + tinted bg), not
   plain bordered boxes.
4. Event popover: **replace the CREW list with a chronological SCHEDULE (לו״ז)
   block**, and remove every **"No invoice"** badge.
5. "Up Next": remove all **"No invoice"** pills — times + locations only.
6. Add the **Workspace Selector** (top-right). On Home there are **no nav tabs**.
7. Use **Bricolage Grotesque** for display type (current build uses a generic
   sans).

## Fonts (Google Fonts)
- Display / titles / section headings / calendar month / agenda day numbers:
  **Bricolage Grotesque**, weight 800, tight tracking; giant hero title sets
  `font-variation-settings:"opsz" 96`.
- Body / labels / UI: **Assistant**.
- Hebrew show names: keep `dir="auto"`; **Heebo**/Assistant render them.
- Stack: `'Bricolage Grotesque','Assistant','Heebo',system-ui,sans-serif`.
- Base body: `letter-spacing:-.005em; line-height:1.5;` antialiased.

## Color tokens (exact)
```
--bg:#F1EEE9; --surface:#FBF8F2; --surface-2:#FFFDF8; --surface-sunk:#EBE7E0;
--border:#DDD7CE; --border-light:#E7E2D9; --border-strong:#C8C1B5;
--text:#1A1714; --text-2:#6B6259; --text-3:#A39A91;
--accent:#3852B4; --accent-hover:#2D4399; --accent-soft:#E8ECF7;
--danger:#C0392B;
```
Artist palette (color / soft bg), assigned stably per artist:
| Artist | Color | Soft bg |
|---|---|---|
| 1 | `#3852B4` indigo | `#E8ECF7` |
| 2 | `#F08D39` terracotta | `#FCE3CC` |
| 3 | `#C79A3F` mustard | `#F6EDD7` |
| 4 | `#4E7265` teal | `#E6EDEA` |

**Shadows are HARD offset (no blur):** cards `5px 5px 0 var(--text)`, stat boxes
`4px 4px 0 var(--surface-sunk)`, workspace pill `3px 3px 0 var(--text)`.
Borders: hairline `1.5px solid var(--text)` on chunky elements, `1px
var(--border-light)` on inner dividers. Radius 6px small / 999px pills.
No gradients, no soft drop-shadows.

## Layout & spacing
- **Header**: sticky, height 72px, padding `0 40px`, border-bottom `1px solid
  var(--text)`, translucent cream bg + backdrop-blur.
- **Main**: max-width 1320px, centered, padding `48px 40px 96px`.
- **Hero**: eyebrow → title `clamp(3.5rem,8vw,6rem)` / lh .9 / ls -.05em (period
  in `--accent`) → sub line "Tuesday, 2 June 2026 · N active artists · N shows
  this month" with thin 34px rule separators. Bottom border `2px solid
  var(--text)`, margin-bottom 30px.
- **Stat strip**: 3 equal cols, gap 18px, margin-bottom 30px. Box: border 1.5px
  text, bg surface-2, padding `24px 26px`, shadow 4px4px0 surface-sunk; number
  3.1rem/800/tabular; label .72rem/700 uppercase ls .1em text-3 with a 7px
  --accent dot. Labels: **Total Upcoming Shows · Active Artists · Open Tasks**.
- **Dashboard grid**: `minmax(0,1fr) / 372px`, gap 24px (calendar left, Up Next
  right). Collapse to 1 col under 1100px.

## Components

### Artist filter chips (above calendar)
Pill row. Chip: 1.5px var(--border), bg surface-2, padding 8px 15px, 10px
artist-color swatch, name, small count pill. "All artists" chip = border
var(--text) + bold. OFF state: opacity .5 + dashed border + grey swatch.
Toggling filters **both** calendar and Up Next.

### Master Calendar
Card border 1.5px text + shadow 5px5px0 text. Header (padding 20/24, border-bottom
1.5px text): month Bricolage 1.55rem/800 + year in text-3; ‹ Today › arrows
(34px bordered squares); Month/Week segmented toggle (active = --accent bg,
white). Weekday row .66rem/700 uppercase text-3. Day cells min-height 118px, 1px
border-light grid; out-of-month bg surface-sunk; TODAY bg --accent-soft with day
number in filled --accent circle.
**Event pill**: bg = artist soft tint, border-LEFT 3px artist color, radius 6,
padding 4/8, .72rem/600 = bold tabular time + SHOW NAME (Hebrew, ellipsis). Max 2
per day then "+N more". Hover: nudge + 2px hard shadow in artist color. Selected:
solid artist-color fill, white text.

### Quick View popover (event click)
Width 300px, border 1.5px text, hard large shadow; anchored next to the cell,
flips to stay inside the card. 7px artist-color band + white ✕. Body:
- Artist eyebrow (.66rem/700 uppercase artist color + dot)
- Title Bricolage 1.2rem/800 (show name, dir="auto")
- "June D, 2026 · Doors HH:MM" in text-2
- **Venue** row: 64px label column (.6rem/700 uppercase text-3) + venue value
  with address as a smaller sub-line
- **Schedule · לו״ז** block: chronological milestones, each = tabular bold time
  in artist color + label: Load-in, Soundcheck, Doors, **Show** (bold/peak),
  Strike. Derive: soundcheck = load-in +75m, doors = show −30m, strike = show
  +150m.
- Footer (top border): right-aligned **"Open show →"** link only (.72rem/700
  uppercase --accent). **No crew list, no invoice badge.**

### Up Next (sidebar)
Card shell, heading "Up Next" + "Next 7". Each row: date block (big day number
Bricolage 1.5rem/800 + "JUN" + weekday) · 3px artist-color bar · artist eyebrow
(uppercase artist color + dot) · show name (bold, ellipsis) · meta "HH:MM ·
Venue". **No flag/badge pills.**

### My Tasks (full-width)
Heading "My Tasks" + "Assigned to you · across all productions". One full-width
card (border 1.5px text, shadow 5px5px0 text) with a **2-column grid** of tasks
(1 col under 760px). Each task: 21px square checkbox (checks to --accent fill +
white tick, strikes text), text .95rem/500, meta = artist swatch+name · show ·
"Due X" pushed right. **No "Red Flags / Overdue" column.**

### Top-right cluster & Workspace Selector (the home-nav pattern)
Cluster: `[theme 34px] [bell 34px] [WORKSPACE SELECTOR] [avatar 34px charcoal
circle, white initials]`. No nav tabs on Home.
**Trigger pill**: height 46px, border 1.5px text, bg surface-2, radius 999px,
shadow 3px3px0 text. Inside: "globe" dot (indigo ring + filled center), tiny
"WORKSPACE" eyebrow above current label ("Global Home"), caret. Hover nudges
up-left.
**Dropdown** (288px, border 1.5px text, hard large shadow, anchored top-right):
- "Switch workspace" header (uppercase, text-3)
- **"Global Home"** row — ACTIVE (bg --accent-soft, globe dot, "All artists" sub,
  ✓ in --accent). Fixed first item.
- "Artists" divider
- One row per artist: color swatch + name + "→" arrow (slides on hover)
- Footer: "Opening an artist enters its isolated workspace — Shows · Crew · Tools
  appear in the nav. Return here anytime via Global Home."
**Behavior**: selecting an artist sets the trigger to that artist (dot = artist
color, label = name), reveals contextual nav tabs (Shows · Crew · Tasks · Tools)
in the header with the active underline in the artist's color, and shows a brief
toast "Entering {artist}'s workspace…". Selecting "Global Home" hides the tabs
and returns here. **There is intentionally no standalone "Home" tab.**

## Existing codebase notes
- React, no router — navigation is `page` state in `src/App.jsx`. Add a `home`
  page (default) and source data via `fetch('/api/shows')`, `/api/crew`, etc.
- ⚠️ Shows have **no `artist`/tenant field yet** — decide the artist mapping with
  the product owner before wiring color-coding/filters (add `artistId` + a stable
  per-artist color, or temporarily derive it).
- Keep `dir="auto"` and the `:lang(he)` font behavior on all user text.

## Files
- `Master Dashboard.html` — the design reference (interactive).
